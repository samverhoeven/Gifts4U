<div class='ewd-uwcf-filters'>

	<form id='ewd-uwcf-filtering-form'>

		<?php $this->print_shortcode_args(); ?>

		<?php $this->maybe_print_reset_all_button(); ?>

		<?php $this->maybe_print_text_search(); ?>

		<?php $this->maybe_print_price_filtering(); ?>

		<?php $this->maybe_print_ratings_filtering(); ?>

		<?php $this->maybe_print_instock_filtering(); ?>

		<?php $this->maybe_print_onsale_filtering(); ?>

		<?php $this->maybe_print_color_filtering(); ?>

		<?php $this->maybe_print_size_filtering(); ?>

		<?php $this->maybe_print_category_filtering(); ?>

		<?php $this->maybe_print_tag_filtering(); ?>

		<?php $this->maybe_print_attribute_filtering(); ?>

	</form>

</div>