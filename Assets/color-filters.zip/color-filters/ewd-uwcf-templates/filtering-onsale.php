<div class='ewd-uwcf-onsale-filtering'>
	<input type='checkbox' class='ewd-uwcf-onsale-checkbox' name='ewd-uwcf-onsale-checkbox' <?php echo ( isset( $_GET['onsale'] ) ? 'checked' : '' ); ?> />
	<span class='ewd-uwcf-onsale-text'><?php _e( 'Sale Items Only', 'color-filters' ); ?></span>
</div>