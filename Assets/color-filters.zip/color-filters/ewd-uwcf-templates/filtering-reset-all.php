<div class='ewd-uwcf-reset-all'>
	<?php _e( 'Reset All Filters', 'color-filters'); ?>
</div>