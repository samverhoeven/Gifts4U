<div class='ewd-uwcf-instock-filtering'>
	<input type='checkbox' class='ewd-uwcf-instock-checkbox' name='ewd-uwcf-instock-checkbox' <?php echo ( isset( $_GET['instock'] ) ? 'checked' : '' ); ?> />
	<span class='ewd-uwcf-instock-text'><?php _e( 'In-Stock Items Only', 'color-filters' ); ?></span>
</div>